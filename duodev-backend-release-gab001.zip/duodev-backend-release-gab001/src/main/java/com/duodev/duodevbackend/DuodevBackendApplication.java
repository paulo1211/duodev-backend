package com.duodev.duodevbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DuodevBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(DuodevBackendApplication.class, args);
	}

}
