package com.duodev.duodevbackend.enums;


public enum Status {
    AGENDADO,
    ANDAMENTO,
    FINALIZADO,
    CANCELADO
}
