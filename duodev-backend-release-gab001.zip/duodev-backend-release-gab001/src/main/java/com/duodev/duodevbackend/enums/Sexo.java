package com.duodev.duodevbackend.enums;


public enum Sexo {
    MASCULINO,
    FEMININO,
    NAO_BINARIO,
    OUTRO,
    PREFIRO_NAO_DECLARAR
}
