package com.duodev.duodevbackend.repository;

import com.duodev.duodevbackend.model.Competencia;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CompetenciaRepository extends JpaRepository<Competencia, Integer> {

}
