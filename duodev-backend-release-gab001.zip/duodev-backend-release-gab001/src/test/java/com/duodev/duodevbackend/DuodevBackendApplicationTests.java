package com.duodev.duodevbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DuodevBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
