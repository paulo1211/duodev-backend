package com.duodev.duodevbackend.repository;

import com.duodev.duodevbackend.model.UsuarioAreaInteresse;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsuarioAreaInteresseRepository extends JpaRepository<UsuarioAreaInteresse, Integer> {
}
